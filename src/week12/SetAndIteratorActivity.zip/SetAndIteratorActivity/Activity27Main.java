package week12.SetAndIteratorActivity;

public class Activity27Main {
    public static void main(String[] args) {
        MovieCollectionSet movieCollect = new MovieCollectionSet();

        movieCollect.addMovies();
        movieCollect.displayMovies();
    }
}
