package weekEleven.Activity23;

import static weekEleven.Activity23.Recursion.alphaBackwards;
import static weekEleven.Activity23.Recursion.countDown;

public class RecursionTest {
    public static void main(String[] args) {
        countDown(10);

        alphaBackwards('z');
    }
}
