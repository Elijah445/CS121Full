package weekTwo;

import javax.swing.*;

public class UserName {
    public static void main(String[] args) {
        String name = JOptionPane.showInputDialog("Enter your first and last name");

        StringBuilder reverseName = new StringBuilder(name);
        System.out.println(reverseName.reverse());
        System.out.printf("%s\n", name.toUpperCase());
        System.out.printf("%s\n", name.toLowerCase());



    }
}
