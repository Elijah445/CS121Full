package week10.interfaces;

public interface Interactable {
    void createAcc();
    void login();
    void browseMovies();
    void bookMovie();
    void reportIssue(String message);


}
